#!/bin/sh
set -eu

data_dir=${XDG_DATA_HOME:-"$HOME/.local/share"}
rm -f "$data_dir/applications/gfn-cursor-fix.desktop"
rm -f "$data_dir/gfn-cursor-fix/launch.sh" \
      "$data_dir/gfn-cursor-fix/libgfn_cursor_arrow.so" \
      "$data_dir/gfn-cursor-fix/cursor_arrow.c"
rmdir "$data_dir/gfn-cursor-fix" 2>/dev/null || true
printf 'GeForce-NOW-Cursor-Fix entfernt.\n'
