#!/bin/sh
set -eu

here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ "$(uname -m)" != x86_64 ]; then
    echo "Dieses Paket unterstützt nur Linux x86_64." >&2
    exit 1
fi
if ! flatpak info com.nvidia.geforcenow >/dev/null 2>&1; then
    echo "Bitte zuerst die offizielle GeForce-NOW-Flatpak-App installieren." >&2
    exit 1
fi

data_dir=${XDG_DATA_HOME:-"$HOME/.local/share"}
target="$data_dir/gfn-cursor-fix"
applications="$data_dir/applications"

install -d "$target" "$applications"
install -m 644 "$here/cursor_arrow.c" "$target/cursor_arrow.c"
install -m 644 "$here/libgfn_cursor_arrow.so" "$target/libgfn_cursor_arrow.so"
install -m 755 "$here/launch.sh" "$target/launch.sh"

cat > "$applications/gfn-cursor-fix.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=GeForce NOW (Cursor Fix)
Comment=GeForce NOW mit sichtbarem Spielcursor starten
Exec="$target/launch.sh"
Icon=com.nvidia.geforcenow
Terminal=false
Categories=Game;
DESKTOP
printf 'Installiert: %s\n' "$target"
